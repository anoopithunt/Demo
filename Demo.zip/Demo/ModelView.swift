//
//  ModelView.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 22/08/22.
//

import SwiftUI

struct ModelView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ModelView_Previews: PreviewProvider {
    static var previews: some View {
        ModelView()
    }
}
