//
//  SlideInView.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 23/08/22.
//

import SwiftUI

struct SlideInView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SlideInView_Previews: PreviewProvider {
    static var previews: some View {
        SlideInView()
    }
}
