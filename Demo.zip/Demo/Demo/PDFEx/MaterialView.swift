//
//  MaterialView.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 13/08/22.
//

import SwiftUI
//import MaterialComponents.MaterialTextControls_FilledTextAreas
//import MaterialComponents.MaterialTextControls_FilledTextFields
//import MaterialComponents.MaterialTextControls_OutlinedTextAreas
//import MaterialComponents.MaterialTextControls_OutlinedTextFields
////
//struct MaterialView: View {
//
//
//
//    var body: some View {
//
////        let textField = MDCFilledTextField(frame: estimatedFrame)
////               textField.label.text = "Phone number"
////        textField.placeholder = "555-555-5555"
//        textField.leadingAssistiveLabel.text = "This is helper text"
//        textField.sizeToFit()
//        view.addSubview(textField)
//    }
//}
//
//struct MaterialView_Previews: PreviewProvider {
//    static var previews: some View {
//        MaterialView()
//    }
//}
