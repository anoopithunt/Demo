//
//  CkeckoutView.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 06/08/22.
//

import SwiftUI

struct CkeckoutView: View {
    
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct CkeckoutView_Previews: PreviewProvider {
    static var previews: some View {
        CkeckoutView()
    }
}
