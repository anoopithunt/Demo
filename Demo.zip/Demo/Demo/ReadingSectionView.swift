//
//  ReadingSectionView.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 10/08/22.
//

import SwiftUI
import PDFKit
struct ReadingSectionView: View {
    var body: some View {
        
        
        
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct ReadingSectionView_Previews: PreviewProvider {
    static var previews: some View {
        ReadingSectionView()
    }
}
