//
//  DemoApp.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 05/08/22.
//

import SwiftUI
import PDFKit

@main
struct DemoApp: App {
    
//    @UIApplicationDelegateAdaptor(AppDelegate.self) var delegate
    var body: some Scene {
        WindowGroup {

         SideMenuViews()
            
//            HomeViews()
          

        }
    }
}
