//
//  Publisher.swift
//  Demo
//
//  Created by Sandeep Kesarwani on 24/08/22.
//

import Foundation
struct Publisher: Codable{
    var userslist: Userslist]
}
